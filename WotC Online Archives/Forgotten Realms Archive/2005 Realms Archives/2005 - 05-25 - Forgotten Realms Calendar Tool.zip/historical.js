// See the notes.txt file for information on modifying this file.

aValidHistoric = new Array("hp13720101", "hp137213X");

var hp13720101 = "<li> For information on adding your own historic notes see the notes.txt file.";

var hp137213X = "<li> 1372 Year of Wild Magic: By the midpoint of the year, several events have signaled a shift in the balance of power for all of Faerun. ";



