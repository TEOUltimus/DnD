// See the notes.txt file for information on modifying this file.

aValidPersonal = new Array("pp13720101");

var pp13720101 = "<li> For information on adding your own personal notes see the notes.txt file.";