// This file contains the master data for the contents of the Barrels, Crates, and Sacks

var bcsversion = "v1.0.1";



// 0) ID
// 1) Name
// 2) Number of Coins
// 3) Coin Value
// 4) Unit of Measure
// 5) Barrel 0:0:0=none 1:0:0=sm 0:1:0=med 0:0:1=lg  
// 6) Crate 0:0:0=none 1:0:0=sm 0:1:0=med 0:0:1=lg  
// 7) Sack 0:0:0=none 1:0:0=sm 0:1:0=med 0:0:1=lg  
// 8) Type 
//	0	D=Dried
//	1	N=Nuts
//	2	S=Sweetner
//	3	SS=Spice/Seasoning
//	4	F=Flour
//	5	C=Corn
//	6	O=Oils
// 	7	M=Meat
//	8	Fi=Fish
//	9	E=Exotic
//	10	Sp=Spirits
//	11	Co=Commodities
//	12	P=Precious Metals
//	13	X1=Miscellaneous Goods
//	14	X2=Miscellaneous Misc
//	15	X3=Miscellaneous Weapons
//	16	X4=Miscellaneous Armor and Shields
//	17	X5=Treasure Gems
//	18	X6=Treasure Art Objects
//	19	X7=Treasure Magic Items
// 9) Table Entries - This is a way to determine how many entries on the random table an item gets.
//          Setting this value to 0 removes it from the list. Increasing this number increases the 
//          chance to get the given item in a container. 


// Arms and Equipment Guide
//	Table 2-4: Edible Items
//	Table 2-9: Commodities

// Players Handbook
// Table 7-3: Trade Goods

var contentelements = 10;

var contents = new Array(
"1","Almonds",3,"gp","lb","1:0:0","1:0:0","1:1:1","N",1,
"2","Cashews",20,"gp","lb","0:0:0","0:0:0","1:0:0","N",1,
"3","Chestnuts",1,"gp","lb","1:1:0","1:1:0","1:1:1","N",1,
"4","Hazelnuts",5,"sp","lb","1:1:1","1:1:1","1:1:1","N",1,
"5","Pine Nuts",10,"gp","lb","0:0:0","1:0:0","1:1:0","N",1,
"6","Pistachios",15,"gp","lb","0:0:0","0:0:0","1:0:0","N",1,
"7","Walnuts",3,"sp","lb","1:1:1","1:1:1","1:1:1","N",1,

"8","Honey",1,"sp","pt","1:1:1","0:0:0","0:0:0","S",1,
"9","Marzipan",20,"gp","oz","1:0:0","0:0:0","0:0:0","S",1,
"10","Molassas",5,"sp","pt","1:1:1","0:0:0","0:0:0","S",1,
"11","Sorghum",3,"sp","pt","1:1:1","0:0:0","0:0:0","S",1,
"12","Sugar",1,"gp","lb","1:1:1","1:1:1","1:1:1","S",1,

"13","Barley",2,"gp","lb","1:1:1","1:1:0","1:1:1","F",1,
"14","Buckwheat",1,"gp","lb","1:1:1","1:1:0","1:1:1","F",1,
"15","Rye",15,"gp","lb","1:0:0","1:0:0","1:1:1","F",1,
"16","Wheat",3,"gp","lb","1:1:1","1:1:0","1:1:1","F",1,

"17","Barley",1,"gp","lb","1:1:1","1:1:0","1:1:1","C",1,
"18","Buckwheat",5,"gp","lb","1:0:0","1:1:0","1:1:1","C",1,
"19","Chick peas",3,"gp","lb","1:0:0","1:1:0","1:1:1","C",1,
"20","Lentils",2,"gp","lb","1:1:0","1:1:0","1:1:1","C",1,
"21","Millet",7,"gp","lb","1:1:0","1:1:0","1:1:1","C",1,
"22","Oats",7,"gp","lb","1:1:0","1:1:0","1:1:1","C",1,
"23","Rice",5,"gp","lb","1:1:1","1:1:1","1:1:1","C",1,
"24","Rye",7,"gp","lb","1:1:0","1:1:0","1:1:1","C",1,
"25","Wheat",1,"gp","lb","1:1:1","1:1:1","1:1:1","C",1,

"26","Apples",1,"gp","lb","1:1:1","1:1:1","1:1:1","D",1,
"27","Apricots",15,"gp","lb","1:0:0","1:0:0","1:1:0","D",1,
"28","Carrots",1,"gp","oz","1:1:1","1:1:1","1:1:1","D",1,
"29","Cherries",5,"sp","oz","1:1:1","1:1:1","1:1:1","D",1,
"30","Currants",1,"sp","oz","1:1:1","1:1:1","1:1:1","D",1,
"31","Dates",5,"gp","oz","1:0:0","1:1:0","1:1:1","D",1,
"32","Elderberries",1,"sp","oz","1:1:1","1:1:1","1:1:1","D",1,
"33","Figs",7,"gp","oz","1:0:0","1:1:0","1:1:1","D",1,
"34","Green beans",2,"sp","oz","1:1:1","1:1:1","1:1:1","D",1,
"35","Green peas",2,"sp","lb","1:1:1","1:1:1","1:1:1","D",1,
"36","Mushrooms",1,"gp","lb","1:1:1","1:1:1","1:1:1","D",1,
"37","Onions",5,"sp","oz","1:0:0","1:1:0","1:1:1","D",1,
"38","Peaches",15,"gp","lb","1:0:0","1:0:0","1:1:0","D",1,
"39","Pears",5,"gp","lb","1:0:0","1:1:0","1:1:1","D",1,
"40","Prunes",3,"gp","lb","1:1:0","1:1:0","1:1:1","D",1,
"41","Raisins",1,"gp","lb","1:1:1","1:1:1","1:1:1","D",1,
"42","Tomatos",1,"gp","lb","1:1:1","1:1:1","1:1:1","D",1,

"43","Angelica",5,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"44","Anise",3,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"45","Basil",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"46","Bergamont",3,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"47","Borage",2,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"48","Caraway",2,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"49","Cardamon",1,"gp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"50","Chives",2,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"51","Cinnamon",1,"gp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"52","Clary",8,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"53","Cloves",20,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"54","Coriander",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"55","Costmary",1,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"56","Cubeb",15,"gp","oz","1:0:0","1:0:0","1:1:0","SS",1,
"57","Cumin",3,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"58","Dillweed",3,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"59","Fennel Seed",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"60","Fenugreek",3,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"61","Garlic",1,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"62","Ginger",10,"gp","oz","1:0:0","1:0:0","1:1:0","SS",1,
"63","Horehound",4,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"64","Horseradish",1,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"65","Hyssop",5,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"66","Juniper",3,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"67","Laurel",4,"gp","oz","1:1:0","1:1:0","1:1:1","SS",1,
"68","Lemon balm",2,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"69","Liquorice root",4,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"70","Lovage",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"71","Mace",25,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"72","Majoram",5,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"73","Mint",3,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"74","Mustard seed",5,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"75","Nutmeg",30,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"76","Oregano",2,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"77","Parsley",4,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"78","Pepper",30,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"79","Poppy seed",8,"gp","oz","1:0:0","1:0:0","1:1:1","SS",1,
"80","Rose hips",5,"gp","oz","1:0:0","1:1:0","1:1:1","SS",1,
"81","Rosemary",5,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"82","Saffron",65,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"83","Sage",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"84","Salt",1,"cp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"85","Sweet cicely",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"86","Tarragon",1,"gp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"87","Thyme",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,
"88","Turmeric",25,"gp","oz","0:0:0","0:0:0","1:0:0","SS",1,
"89","Woodruff",1,"sp","oz","1:1:1","1:1:1","1:1:1","SS",1,

"90","Olive oil",5,"gp","gal","1:0:0","0:0:0","0:0:0","O",1,
"91","Almond oil",10,"gp","gal","1:0:0","0:0:0","0:0:0","O",1,
"92","Walnut oil",2,"gp","gal","1:0:0","0:0:0","0:0:0","O",1,
"93","Hazelnut oil",3,"gp","gal","1:0:0","0:0:0","0:0:0","O",1,
"94","Sesame oil",10,"gp","gal","1:0:0","0:0:0","0:0:0","O",1,
"95","Sunflower oil",3,"sp","gal","1:1:1","0:0:0","0:0:0","O",1,
"96","Safflower oil",2,"sp","gal","1:1:1","0:0:0","0:0:0","O",1,
"97","Rapeseed oil",1,"sp","gal","1:1:1","0:0:0","0:0:0","O",1,

"98","Beef, Corned",3,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"99","Beef, Dried",5,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"100","Beef, Jerked",7,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"101","Beef, Sausage",2,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"102","Beef, Smoked",4,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"103","Buffalo, Dried",30,"gp","lb","0:0:0","1:0:0","0:0:0","M",1,
"104","Buffalo, Jerked",45,"gp","lb","0:0:0","1:0:0","0:0:0","M",1,
"105","Cod, Salted",5,"gp","lb","0:0:0","1:1:0","0:0:0","Fi",1,
"106","Cod, Smoked",7,"gp","lb","0:0:0","1:1:0","0:0:0","Fi",1,
"107","Herring, Pickled",3,"gp","lb","1:1:0","1:1:0","0:0:0","Fi",1,
"108","Herring, Salted",5,"gp","lb","0:0:0","1:1:0","0:0:0","Fi",1,

"109","Pork, Bacon",4,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"110","Pork, Ham",5,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"111","Pork, Salted",3,"gp","lb","0:0:0","1:1:0","0:0:0","M",1,
"112","Pork, Sausage",1,"gp","lb","0:0:0","1:1:1","0:0:0","M",1,
"113","Salmon, Salted",10,"gp","lb","0:0:0","1:0:0","0:0:0","Fi",1,
"114","Salmon, Smoked",15,"gp","lb","0:0:0","1:0:0","0:0:0","Fi",1,
"115","Sardines",4,"gp","lb","1:1:0","1:1:0","0:0:0","Fi",1,

"116","Chillies",25,"gp","lb","1:0:0","1:0:0","0:0:0","E",1,
"117","Coffee",50,"gp","lb","1:0:0","1:0:0","1:1:1","E",1,
"118","Coconut",50,"gp","lb","1:0:0","1:0:0","1:1:0","E",1,
"119","Hickory nuts",200,"gp","lb","0:0:0","0:0:0","1:0:0","E",1,
"120","Lotus",100,"gp","oz","0:0:0","0:0:0","1:0:0","E",1,
"121","Maple sugar",75,"gp","gal","1:0:0","0:0:0","0:0:0","E",1,
"122","Paprika",30,"gp","oz","1:0:0","1:0:0","1:1:0","E",1,
"123","Pimento",40,"gp","oz","1:0:0","1:0:0","0:0:0","E",1,
"124","Sarsaparilla",10,"gp","oz","1:0:0","0:0:0","0:0:0","E",1,
"125","Tobacco",5,"sp","lb","0:0:0","1:1:0","1:1:1","E",1,
"126","Vanilla",75,"gp","oz","1:0:0","0:0:0","0:0:0","E",1,
"127","Walnuts, black",100,"gp","lb","0:0:0","0:0:0","1:0:0","E",1,

"128","Ale, Dragonbite bitter",15,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"129","Ale, Dwarfhead stout",30,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"130","Mead, Elven",60,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"131","Mead, Golden light, gnome",10,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"132","Mead, Thudrin, goblin",2,"gp","gal","1:1:0","0:0:0","0:0:0","Sp",1,
"133","Ale, Pulsh brown",8,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,

"134","Frostwine",40,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"135","Aleeian wine, elven",100,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"136","Garnet wine, dwarven",90,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"137","Mushroom wine",77,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,
"138","Spiderblood wine, drow",150,"gp","gal","1:0:0","0:0:0","0:0:0","Sp",1,

"139","Unused",1,"gp","gal","0:0:0","0:0:0","0:0:0","Sp",0,
"140","Unused",1,"gp","gal","0:0:0","0:0:0","0:0:0","Sp",0,
"141","Unused",1,"gp","gal","0:0:0","0:0:0","0:0:0","Sp",0,
"142","Unused",1,"gp","gal","0:0:0","0:0:0","0:0:0","Sp",0,
"143","Unused",1,"gp","gal","0:0:0","0:0:0","0:0:0","Sp",0,

"144","Alchemical materials, unusual",50,"sp","oz","1:1:1","1:1:1","1:1:1","Co",1,
"145","Alchemical materials, rare",7,"gp","oz","1:1:0","1:1:0","1:1:1","Co",1,
"146","Alchemical materials, exotic",18,"gp","oz","1:0:0","1:0:0","1:1:1","Co",1,
"147","Arcane material, rare",1,"gp","lb","1:1:1","1:1:1","1:1:1","Co",1,
"148","Arcane material, exotic",15,"gp","oz","1:1:0","1:1:0","1:1:1","Co",1,
"149","Arcane material, unique",62,"gp","oz","1:0:0","1:0:0","1:1:1","Co",1,
"150","Cosmetics, common",50,"cp","oz","1:1:1","1:1:1","1:1:1","Co",1,
"151","Cosmetics, unusual",50,"sp","oz","1:1:1","1:1:1","1:1:1","Co",1,
"152","Cosmetics, rare",7,"gp","oz","1:1:0","1:1:0","1:1:1","Co",1,
"153","Cosmetics, exotic",18,"gp","oz","1:0:0","1:0:0","1:1:1","Co",1,
"154","Fabric, common",1,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"155","Fabric, fine",25,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"156","Fabric, unusual",50,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"157","Fabric, exotic",1,"gp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"158","Furniture, plain",3,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"159","Furniture, fine",7,"sp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"160","Furniture, exotic",18,"sp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"161","Furs and hides, common",3,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"162","Furs and hides, unusual",7,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"163","Furs and hides, rare",15,"sp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"164","Furs and hides, exotic",30,"sp","lb","0:0:0","1:0:0","0:0:0","Co",1,
"165","Furs and hides, monsterous",4,"gp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"166","Lumber, local",7,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"167","Lumber, unusual",18,"sp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"168","Lumber, exotic",30,"sp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"169","Paints and dyes, common",50,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"170","Paints and dyes, unusual",7,"gp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"171","Paints and dyes, rare",18,"gp","lb","0:0:0","1:1:0","0:0:0","Co",1,
"172","Paints and dyes, exotic",30,"gp","lb","0:0:0","1:0:0","0:0:0","Co",1,
"173","Perfume, common",50,"sp","oz","1:0:0","1:1:1","0:0:0","Co",1,
"174","Perfume, unusual",7,"gp","oz","1:0:0","1:1:0","0:0:0","Co",1,
"175","Perfume, rare",18,"gp","oz","1:0:0","1:0:0","0:0:0","Co",1,
"176","Perfume, exotic",30,"gp","oz","1:0:0","1:0:0","0:0:0","Co",1,
"177","Rugs and tapestries, common",30,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"178","Rugs and tapestries, unusual",70,"sp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"179","Rugs and tapestries, rare",2,"gp","lb","0:0:0","1:1:1","0:0:0","Co",1,
"180","Rugs and tapestries, exotic",12,"gp","lb","0:0:0","1:1:0","0:0:0","Co",1,

"181","Copper",5,"sp","lb","1:1:1","1:1:1","1:1:1","P",2,
"182","Silver",5,"gp","lb","1:1:1","1:1:1","1:1:1","P",2,
"183","Gold",50,"gp","lb","1:1:1","1:1:1","1:1:1","P",2,
"184","Platinum",500,"gp","lb","1:1:1","1:1:1","1:1:1","P",2,

"185","BarrelGoods",0,"gp","lb","1:1:1","0:0:0","0:0:0","X1",10,
"186","CrateGoods",0,"gp","lb","0:0:0","1:1:1","0:0:0","X1",10,
"187","SackGoods",0,"gp","lb","0:0:0","0:0:0","1:1:1","X1",10,

"188","BarrelMisc",0,"gp","lb","1:1:1","0:0:0","0:0:0","X2",10,
"189","CrateMisc",0,"gp","lb","0:0:0","1:1:1","0:0:0","X2",10,
"190","SackMisc",0,"gp","lb","0:0:0","0:0:0","1:1:1","X2",10,

"191","BarrelWeapons",0,"gp","lb","1:1:1","0:0:0","0:0:0","X3",10,
"192","CrateWeapons",0,"gp","lb","0:0:0","1:1:1","0:0:0","X3",10,
"193","SackWeapons",0,"gp","lb","0:0:0","0:0:0","1:1:1","X3",10,

"194","BarrelArmor",0,"gp","lb","1:1:1","0:0:0","0:0:0","X4",10,
"195","CrateArmor",0,"gp","lb","0:0:0","1:1:1","0:0:0","X4",10,
"196","SackArmor",0,"gp","lb","0:0:0","0:0:0","1:1:1","X4",10,

"197","Gems",0,"gp","lb","1:1:1","1:1:1","1:1:1","X5",5,

"198","ArtObjects",0,"gp","lb","1:1:1","1:1:1","1:1:1","X6",5,

"199","MagicItems",0,"gp","lb","1:1:1","1:1:1","1:1:1","X7",5
);

var barrelmisc = new Array(
"The barrel is filled with water",
"The barrel is filled with water",
"The barrel is filled with water",
"The barrel is filled with water",
"The barrel is filled with water",
"The barrel is empty",
"The barrel is empty",
"The barrel is empty",
"The barrel is empty",
"The barrel is empty",
"The barrel is filled with water and at its bottom rests a single gold key.",
"A single small scrap of paper with a bizarre symbol on it (Other).",
"A skeletal human foot (Other).",
"A piece of partially burnt cloth (Other).",
"A wooden prosthetic limb (Other).",
"A message scroll, sealed with wax and a royal seal (Other).",
"A pair of old ivory dice (Other).",
"A pair of old shoes (Other).",
"A single broken monocle (Other).",
"A human skeleton (Other).",
"A human skeleton missing the skull (Other).",
"A dragons egg -- DM's choice (Other).",
"A staircase leading down (Other).",
"A sleeping kobold (Other).",
"A finger (Other).",
"A scrap of blank paper (Other).",
"A skull with gems in the eye and golden teeth (Other).",
"A strange glowing gem (Other).",
"A mummified hand, eye, and head (missing an eye) (Other).",
"A rusty dagger (Other).",
"A large lump of wax (Other).",
"Broken glass (Other).",
"Cobwebs (Other).",
"Corks from hundreds of wine bottles (Other).",
"Dragon bones (Other).",
"Dried flowers (Other).",
"Feathers from various species of bird (Other).",
"Fresh blood (Other).",
"Foul-smelling slime (Other).",
"Holy water (Other).",
"Holy symbols from various faiths (Other).",
"Hundreds of different candles (Other).",
"Hundreds of polished marbles (Other).",
"Hundreds of tiny ivory monkey figurines (Other).",
"Hundreds of glass eyes (Other).",
"It is empty, but there is a horrid smell (Other).",
"Ink, liquid (Other).",
"Ink, powdered (Other).",
"Oil-soaked rags (Other).",
"Old, disheveled clothing, splattered with blood (Other).",
"Rag dolls (Other).",
"Rusty chains (Other).",
"Sand (Other).",
"Sawdust (Other).",
"Soil (Other).",
"The bones of 4d6 fish (Other).",
"The severed head of a Kolyarut (Other). ",
"1d4 Small blue glass frog figurines (Other).",
"1d6 Theatre costumes (Other).",
"1d8 Unfinished sword blades (Other).",
"3d6 Bundles of twine (Other).",
"4d6 Pickled pig's feet (Other).",
"4d6 Pickled hard boiled chicken eggs (Other).",
"Several mice scurry out a hole near the bottom of the barrel (Other).",
"Several rats scurry out a hole near the bottom of the barrel (Other)."
);

var cratemisc = new Array(
"The crate is empty",
"The crate is empty",
"The crate is empty",
"The crate is empty",
"The crate is empty",
"The crate is filled with hundreds of rusty old keys and a single gold key.",
"A single small scrap of paper with a bizarre symbol on it (Other).",
"A skeletal human foot (Other).",
"A piece of partially burnt cloth (Other).",
"A wooden prosthetic limb (Other).",
"A message scroll, sealed with wax and a royal seal (Other).",
"A pair of old ivory dice (Other).",
"A pair of old shoes (Other).",
"The crate contains a single pair of spectacles (Other).",
"A human skeleton (Other).",
"A human skeleton missing a leg (Other).",
"A dragons egg -- DM's choice (Other).",
"A staircase leading down (Other).",
"A sleeping kobold (Other).",
"A toe (Other).",
"A scrap of blank paper (Other).",
"A skull with gems in the eye and golden teeth (Other).",
"A strange glowing gem (Other).",
"A rusty dagger and a moldy loaf of bread (Other).",
"A large lump of wax (Other).",
"Broken glass (Other).",
"Cobwebs (Other).",
"Corks from hundreds of wine bottles (Other).",
"Dragon bones (Other).",
"Dried flowers (Other).",
"Feathers from various species of bird (Other).",
"Holy symbols from various faiths (Other).",
"Hundreds of different candles (Other).",
"Hundreds of polished marbles (Other).",
"Hundreds of glass eyes (Other).",
"It is empty, but there is a horrid smell (Other).",
"Old, disheveled clothing, splattered with blood (Other).",
"Rag dolls (Other).",
"Rusty chains (Other).",
"Sand (Other).",
"Sawdust (Other).",
"Soil (Other).",
"The bones of 4d6 cats (Other).",
"The severed head of a Kolyarut (Other). ",
"1d4 Small red glass frog figurines (Other).",
"1d6 Theatre costumes (Other).",
"1d8 Unfinished axe blades (Other).",
"3d6 Bundles of twine (Other).",
"3d6 Empty, glass jars (Other).",
"Several mice scurry out a hole near the bottom of the crate (Other).",
"Several rats scurry out a hole near the bottom of the crate (Other).",
"The crate is actually a Rogue Modron (Other)."
);

var sackmisc = new Array(
"A skeletal human hand (Other).",
"A piece of partially burnt cloth (Other).",
"A wooden prosthetic limb (Other).",
"A message scroll, sealed with wax and a royal seal (Other).",
"A pair of old shoes (Other).",
"A dragons egg -- DM's choice (Other).",
"A strange glowing gem (Other).",
"A mummified hand (Other).",
"A rusty dagger (Other).",
"A small lump of wax (Other).",
"A skeletal dragons talon (Other).",
"Holy symbols from various faiths (Other).",
"Hundreds of polished marbles (Other).",
"It is empty, but there is a horrid smell (Other).",
"Oil-soaked rags (Other).",
"Old, disheveled clothing, splattered with blood (Other).",
"Sand (Other).",
"Sawdust (Other).",
"Soil (Other).",
"1d4 Small yellow glass frog figurines (Other).",
"2d6 Bundles of twine (Other)."
);

var barrelgoods = new Array(
"2d4 Goods (Adventuring Gear) from PHB Table 7-8",
"2d4 Goods (Special Substances and Items) from PHB Table 7-8",
"2d4 Goods (Tools and Skill Kits) from PHB Table 7-8",
"2d4 Goods (Clothing) from PHB Table 7-8",
"2d4 Goods (Mount Related Gear) from PHB Table 7-8"
);
var crategoods = new Array(
"2d6 Goods (Adventuring Gear) from PHB Table 7-8",
"2d6 Goods (Special Substances and Items) from PHB Table 7-8",
"2d6 Goods (Tools and Skill Kits) from PHB Table 7-8",
"2d6 Goods (Clothing) from PHB Table 7-8",
"2d6 Goods (Mount Related Gear) from PHB Table 7-8"
);
var sackgoods = new Array(
"1d4 Goods (Adventuring Gear) from PHB Table 7-8",
"1d4 Goods (Special Substances and Items) from PHB Table 7-8",
"1d4 Goods (Tools and Skill Kits) from PHB Table 7-8",
"1d4 Goods (Clothing) from PHB Table 7-8",
"1d4 Goods (Mount Related Gear) from PHB Table 7-8"
);






var barrelweapons = new Array(
"2d4 Common Melee Weapons from DMG Table 7-11 or Magic Item Compendium Table A-4 (Weapons)",
"2d4 Uncommon Weapons from DMG Table 7-12 or Magic Item Compendium Table A-4 (Weapons)",
"1d4 Common Ranged Weapons from DMG Table 7-13 or Magic Item Compendium Table A-4 (Weapons)"
);
var crateweapons = new Array(
"2d4 Common Melee Weapons from DMG Table 7-11 or Magic Item Compendium Table A-4 (Weapons)",
"2d4 Uncommon Weapons from DMG Table 7-12 or Magic Item Compendium Table A-4 (Weapons)",
"1d4 Common Ranged Weapons from DMG Table 7-13 or Magic Item Compendium Table A-4 (Weapons)"
);
var sackweapons = new Array(
"1d4 Common Melee Weapons from DMG Table 7-11 or Magic Item Compendium Table A-4 (Weapons)",
"1d4 Uncommon Weapons from DMG Table 7-12 or Magic Item Compendium Table A-4 (Weapons)",
"1d3 Common Ranged Weapons from DMG Table 7-13 or Magic Item Compendium Table A-4 (Weapons)"
);

var barrelarmor = new Array(
"1d4 Pieces of Armor from DMG Table 7-3 or Magic Item Compendium Table A-3 (Armor/Shields)",
"1d2 Shields from DMG Table 7-4 or Magic Item Compendium Table A-3 (Armor/Shields)"
);
var cratearmor = new Array(
"1d6 Pieces of Armor from DMG Table 7-3 or Magic Item Compendium Table A-3 (Armor/Shields)",
"1d3 Shields from DMG Table 7-4 or Magic Item Compendium Table A-3 (Armor/Shields)"
);
var sackarmor = new Array(
"A piece of Armor from DMG Table 7-3 or Magic Item Compendium Table A-3 (Armor/Shields)"
);

var magicitems = new Array(
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"A magic item from DMG Table 7-1 or see Magic Item Compendium Appendix 2 (Magic Items)",
"<a href='javascript:popit(1);' class='popit'>Fist of Emirkul</a> -- D&D Player Rewards Program (Magic Items).",
"<a href='javascript:popit(2);' class='popit'>Olidammara's Dice</a> -- <i>Epic Level Handbook</i> (Magic Items).",
"<a href='javascript:popit(3);' class='popit'>Deck of Many Things</a> -- <i>Dungeon Master's Guide</i> (Magic Items).",
"<a href='javascript:popit(4);' class='popit'>Variant Deck of Many Things</a> -- <i>Player's Handbook II</i> Web Enhancement (Magic Items).",
"<a href='javascript:popit(5);' class='popit'>Rod of Wonder / Greater Rod of Wonder</a> -- <i>Dungeon Master's Guide</i> (Magic Items)."
);


var artobjects = new Array(
"A silver ewer (Art Object), 5gp",
"A carved bone statuette (Art Object), 5gp",
"An ivory statuette (Art Object), 5gp",
"A finely wrought small gold bracelet (Art Object), 5gp",
"A carved wooden bowl of wax fruit (Art Object), 5gp",
"A small painted stone dog statuette (Art Object), 5gp",
"A portrait of a local ruler carved and painted on wooden wall plaque (Art Object), 5gp",
// ===============
"A Silver signet ring depicting a kraken (Art Object), 10gp",
"A gold-tipped griffon-feather quill (Art Object), 10gp",
"A gold plated silver corkscrew with a wooden handle (Art Object), 10gp",
"A finely wrought pewter chalice set with amethyst (Art Object), 10gp",
"A Single real leaf dipped in gold on a silver chain (Art Object), 10gp",
"A simple heart shaped silver locket holds the miniature portrait of a woman (Art Object), 10gp",
"A 5 foot diameter bronze gong with its edge plated in silver (Art Object), 10gp",
"A silver brooch enameled with a design of 3 blue lightning bolts (Art Object), 10gp",
"A flower made of colored crystal (Art Object), 10gp",
"A heavy stone hammer with a rare sunwood handle and its grip wrapped with remoharz leather (Art Object), 10gp",
"A fine multicolored coral bead torque (Art Object), 10gp",
"An ancient urn, almost completely intact (Art Object), 10gp",
"A fine silk cape with silver threads (Art Object), 10gp",
"A single small opal on black velvet choker (Art Object), 10gp",
// ===============
"A Black velvet mask with numerous citrines (Art Object), 100gp",
"A Silver chalice with lapis lazuli gems (Art Object), 100gp",
"A soap dish made of soapstone. A name is scratched on its lip (Art Object), 100gp",
"A detailed silver mask of a smiling raskasha (Art Object), 100gp",
"A darkwood hat stand shaped like a tree (Art Object), 100gp",
"A satchel made from shocker lizard hide (Art Object), 100gp",
"A flawless amber sphere containing a bronze-colored praying mantis (Art Object), 100gp",
"A silver teapot with a fluted handle (Art Object), 100gp",
"A pair of ivory chopsticks (Art Object), 100gp",
"A capped with silver on both ends (Art Object), 100gp",
"A golden bowl with the name of a local ruler engraved at its bottom (Art Object), 100gp",
"A silver dagger with a bloodstone at the end of the hilt (Art Object), 100gp",
// ===============
"A large well-done wool tapestry (Art Object), 350gp",
"A brass mug with jade inlays (Art Object), 350gp",
"A crystal decanter, cut to scatter light into a rainbow of colors (Art Object), 350gp",
"A soft wool rug with silk accents and intricate floral designs (Art Object), 350gp",
"A silver ring with uniquely-shaped emerald (Art Object), 350gp",
"A bracelet in the form of a golden centipede (Art Object), 350gp",
"An ivory carving of a swooping eagle, with sapphire eyes (Art Object), 350gp",
"A small but incredibly detailed carving of a sea turtle in gold (Art Object), 350gp",
// ===============
"A silver comb with moonstones (Art Object), 550gp",
"A silver-plated steel longsword with jet jewel in hilt (Art Object), 550gp",
"A red silk corset with adamantine brocade (Art Object), 550gp",
"A 12-inch onyx and fire opal statue of a Nightmare (Art Object), 550gp",
"A gold hilted sword with a large amethyst at its quillons and its pommel (Art Object), 550gp",
"A wall tapestry depicting a historical battle (Art Object), 550gp",
"A gold tiara with some small gems (Art Object), 550gp",
// ===============
"A carved harp of exotic wood with ivory inlay and zircon gems (Art Object), 700gp",
"A solid gold idol (10 lb.) (Art Object), 700gp",
"A crystal dish etched with Elven script (Art Object), 700gp",
"A star sapphire carved into a fake eye (Art Object), 700gp",
// ===============
"A gold dragon comb with red garnet eye (Art Object), 1,000gp",
"A gold and topaz bottle stopper cork (Art Object), 1,000gp",
"A ceremonial electrum dagger with a star ruby in the pommel (Art Object), 1,000gp",
"A faceted crystal basket (Art Object), 1,000gp",
// ===============
"An eye patch with mock eye of sapphire and moonstone (Art Object), 1,400gp",
"A fire opal pendant on a fine gold chain (Art Object), 1,400gp",
"An old masterpiece painting (Art Object), 1,400gp",
// ===============
"An embroidered silk and velvet mantle with numerous moonstones (Art Object), 1,750gp",
"A sapphire pendant on gold chain (Art Object), 1,750gp",
// ===============
"An embroidered and bejeweled glove (Art Object), 2,500gp",
"A jeweled anklet (Art Object), 2,500gp",
"A gold music box (Art Object), 2,500gp",
// ===============
"A golden circlet with four aquamarines (Art Object), 3,500gp",
"A necklace of small pink pearls (Art Object), 3,500gp",
"A silver gauntlets with ruby and sapphire inlays (Art Object), 3,500gp",
"A porcelain vase with scenes of a historic battle inlaid around it in solid gold (Art Object), 3,500gp",
"A silver chalice studded with sapphires (Art Object), 3,500gp",
// ===============
"A jeweled gold crown (Art Object), 5,000gp",
"A jeweled electrum ring (Art Object), 5,000gp",
"A golden statue of the Tarrasque with a ruby carapace (Art Object), 5,000gp",
"A foot high carving of a rearing horse in reddish brown jade (Art Object), 5,000gp",
"A life sized carving of a strawberry, made of ruby, with emerald leaves (Art Object), 5,000gp",
// ===============
"A gold and ruby ring (Art Object), 7,000gp",
"A gold cup set with emeralds (Art Object), 7,000gp",
"A solid faceted chalice carved from a single piece of amethyst with jade trimmings at its base (Art Object), 7,000gp",
"A circlet crown carved from a single piece of topaz. Amber orbs top the spires of the crown (Art Object), 7,000gp"
);


var gems = new Array(
"1d4 Banded Agates (Gems), 1gp each",
"1d4 Eye Agate (Gems), 1gp each",
"1d4 Moss Agate (Gems), 1gp each",
"1d4 Azurite (Gems), 1gp each",
"1d4 Blue Quartz (Gems), 1gp each",
"1d4 Hematite (Gems), 1gp each",
"1d4 Lapis Lazuli (Gems), 1gp each",
"1d4 Malachite (Gems), 1gp each",
"1d4 Obsidian (Gems), 1gp each",
"1d4 Rhodochrosite (Gems), 1gp each",
"1d4 Tiger Eye Turquoise (Gems), 1gp each",
"1d4 Freshwater Pearl (Gems), 1gp each",
"2d4 Bloodstone (Gems), 10gp each",
"2d4 Carnelian (Gems), 10gp each",
"2d4 Chalcedony (Gems), 10gp each",
"2d4 Chrysoprase (Gems), 10gp each",
"2d4 Citrine (Gems), 10gp each",
"2d4 Iolite Jasper (Gems), 10gp each",
"2d4 Moonstone (Gems), 10gp each",
"2d4 Onyx (Gems), 10gp each",
"2d4 Peridot (Gems), 10gp each",
"2d4 Rock Crystal (Gems), 10gp each",
"2d4 Sard (Gems), 10gp each",
"2d4 Sardonyx (Gems), 10gp each",
"2d4 Rose Quartz (Gems), 10gp each",
"2d4 Smoky Quartz (Gems), 10gp each",
"2d4 Orstar Rose Quartz (Gems), 10gp each",
"2d4 Zircon (Gems), 10gp each",
"4d4 Amber (Gems), 10gp each",
"4d4 Amethyst (Gems), 10gp each",
"4d4 Chrysoberyl (Gems), 10gp each",
"4d4 Coral (Gems), 10gp each",
"4d4 Red Garnet (Gems), 10gp each",
"4d4 Brown-Green Garnet (Gems), 10gp each",
"4d4 Jade (Gems), 10gp each",
"4d4 Jet (Gems), 10gp each",
"4d4 White Pearl (Gems), 10gp each",
"4d4 Golden Pearl (Gems), 10gp each",
"4d4 Pink Pearl (Gems), 10gp each",
"4d4 Silver Pearl (Gems), 10gp each",
"4d4 Red Spinel (Gems), 10gp each",
"4d4 Red-Brown Spinel (Gems), 10gp each",
"4d4 Deep Green Spinel (Gems), 10gp each",
"4d4 Tourmaline (Gems), 10gp each",
"2d4 Alexandrite (Gems), 100gp each",
"2d4 Aquamarine (Gems), 100gp each",
"2d4 Violet Garnet (Gems), 100gp each",
"2d4 Black Pearl (Gems), 100gp each",
"2d4 Deep Blue Spinel (Gems), 100gp each",
"2d4 Golden Yellow Topaz (Gems), 100gp each",
"4d4 Emerald (Gems), 100gp each",
"4d4 White Opal (Gems), 100gp each",
"4d4 Black Opal (Gems), 100gp each",
"4d4 Fire Opal (Gems), 100gp each",
"4d4 Blue Sapphire (Gems), 100gp each",
"4d4 Fiery Yellow Corundum (Gems), 100gp each",
"4d4 Rich Purple Corundum (Gems), 100gp each",
"4d4 Blue Star Sapphire (Gems), 100gp each",
"4d4 Black Star Sapphire (Gems), 100gp each",
"4d4 Star Ruby (Gems), 100gp each",
"2d4 Clearest Bright Green Emerald (Gems), 1000gp each",
"2d4 Blue-White Diamond (Gems), 1000gp each",
"2d4 Canary Diamond (Gems), 1000gp each",
"2d4 Pink Diamond (Gems), 1000gp each",
"2d4 Brown Diamond (Gems), 1000gp each",
"2d4 Blue Diamond (Gems), 1000gp each",
"2d4 Jacinth (Gems), 1000gp each"
);


// area fill info ===================================================

var blunits = 77;
var bmunits = 51;
var bsunits = 26;
var clunits = 96;
var cmunits = 40;
var csunits = 12;
var slunits = 20;  
var smunits = 10;  
var ssunits = 4;  
var baseunits = 187; // standard 5' x 5' room stacked 5 feet high. 1.496 units/cu.ft
var fillpercent = 100

// 1 ounce = 0.0625 pounds

// Barrel
//	gal	oz	pt	lb	units
// SM	16	2084	128	128	26
// MED	32	4168	256	256	51
// LG	48	8336	384	384	77

// Crate
//	cu.ft.	oz	pt	lb	units
// SM	8	960	60	60	12
// MED	27	3232	202	202	40
// LG	64 	7680	480	480	96

// Sack
//	oz	pt	lb	units
// SM	320	20	20	4
// MED	800	50	50	10
// LG	1600	100	100	20

var contarray=new Array(
16,2084,128,128,	// 0
32,4168,256,256,	// 1
48,8336,384,384,	// 2
8,960,60,60,		// 3
27,3232,202,202,	// 4
64,7680,480,480,	// 5
0,320,20,20,		// 6
0,800,50,50,		// 7
0,1600,100,100		// 8
);

var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")

var hidden = 0;
var start = 0;
var pm = 0; // 0=plus 1=minus

var ct = "off"; // Clear Toggle

var bb = 0;
var bc = 0;
var bs = 0;

var xbb = 0;
var xbc = 0;
var xbs = 0;

var bstot = 0;
var cstot = 0;
var sstot = 0;

var bmtot = 0;
var cmtot = 0;
var smtot = 0;

var bltot = 0;
var cltot = 0;
var sltot = 0;

var bulkrate = 100;
var bulkratex = 1;
var setopt = "hidden";
var contentcostbulk = 0;
var contentcost = 0; 
var ccformat = "";
var bbformat = "";
var printroom = 0;
var showroom = "no"

var pagedisp2 = "";
var pagedisp2b = "";
var pagedisp2c = "";
var pagedisp2s = "";
var pagedisp2p = "";

var pagedisp3 = "";
var pagedisp3bl = "";
var pagedisp3bm = "";
var pagedisp3bs = "";
var pagedisp3cl = "";
var pagedisp3cm = "";
var pagedisp3cs = "";
var pagedisp3sl = "";
var pagedisp3sm = "";
var pagedisp3ss = "";

var pagedisp3x = "";
var pagedisp3blx = "";
var pagedisp3bmx = "";
var pagedisp3bsx = "";
var pagedisp3clx = "";
var pagedisp3cmx = "";
var pagedisp3csx = "";
var pagedisp3slx = "";
var pagedisp3smx = "";
var pagedisp3ssx = "";

var pagetemp3 = "";
var pagetemp3bl = "";
var pagetemp3bm = "";
var pagetemp3bs = "";
var pagetemp3cl = "";
var pagetemp3cm = "";
var pagetemp3cs = "";
var pagetemp3sl = "";
var pagetemp3sm = "";
var pagetemp3ss = "";


var acount = new Array(0,0,0,0,0,0,0,0);

var imgchk = new Array("off","on","off","off","on","off","off","on","off");
var imgchk2 = new Array("yes","yes","yes","yes","yes","yes","yes","yes","yes");
contentoptions = new Array("on","on","on","on","on","on","on","on","on","on","on","on","on","on","on","on","on","on","on","on");

var contentsx = new Array(0);

var contentsbs = new Array(0);
var contentscs = new Array(0);
var contentsss = new Array(0);

var contentsbm = new Array(0);
var contentscm = new Array(0);
var contentssm = new Array(0);

var contentsbl = new Array(0);
var contentscl = new Array(0);
var contentssl = new Array(0);

var tab = "";