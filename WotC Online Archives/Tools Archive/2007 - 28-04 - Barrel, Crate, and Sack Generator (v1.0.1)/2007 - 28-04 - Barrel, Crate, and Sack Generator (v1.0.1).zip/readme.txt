Barrel, Crate, and Sack Generator 

1.0.1 
- Typo "spiderblood" fixed.
- Formula for calculating container cost fixed.
- Simple popup calculator added.

1.0.0 
- Launch Version 